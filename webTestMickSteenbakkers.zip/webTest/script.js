function hideDog(){

    document.getElementById('doggo').style.display = 'none';

}

function showDog(){

    document.getElementById('doggo').style.display = 'inline';
    
}